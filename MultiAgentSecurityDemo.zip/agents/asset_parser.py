
import json
def parse_assets(file_path):
    with open(file_path, "r") as f:
        targets = json.load(f)
    return targets
