
def infer_vulnerabilities(assets):
    return [{"host": a["host"], "vuln": "DemoVuln"} for a in assets]
