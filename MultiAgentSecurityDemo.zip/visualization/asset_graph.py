
import matplotlib.pyplot as plt

def plot_assets(assets, vulns):
    fig, ax = plt.subplots(figsize=(6,4))
    y = range(len(assets))
    hosts = [a['host'] for a in assets]
    vuln_labels = [v['vuln'] for v in vulns]
    
    ax.scatter(hosts, y, s=500, c='skyblue')
    for i, (host, vuln) in enumerate(zip(hosts, vuln_labels)):
        ax.text(host, i, f"{host}\n{vuln}", ha='center', va='center')
    
    ax.set_yticks([])
    ax.set_xlabel("Host")
    ax.set_title("Demo Asset & Vulnerability Graph")
    plt.tight_layout()
    plt.savefig("visualization/demo_plot.png")
    plt.close()
