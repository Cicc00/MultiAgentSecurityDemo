
def evaluate_risks(vulns):
    return [{"host": v["host"], "risk": "High"} for v in vulns]
