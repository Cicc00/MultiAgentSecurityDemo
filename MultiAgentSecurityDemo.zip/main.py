
from agents.asset_parser import parse_assets
from agents.vuln_inference import infer_vulnerabilities
from agents.exploit_gen import generate_exploits
from agents.risk_eval import evaluate_risks
from agents.report_gen import generate_report
from visualization.asset_graph import plot_assets

def main():
    print("=== Multi-Agent Security Demo ===")
    
    assets = parse_assets("data/demo_targets.json")
    vulns = infer_vulnerabilities(assets)
    exploits = generate_exploits(vulns)
    risk_scores = evaluate_risks(vulns)
    report_file = generate_report(assets, vulns, exploits, risk_scores)
    
    plot_assets(assets, vulns)
    
    print(f"Report saved: {report_file}")
    print("Asset & vulnerability graph saved: visualization/demo_plot.png")

if __name__ == "__main__":
    main()
