
def generate_report(assets, vulns, exploits, risks):
    report_file = "demo_output/report_demo.txt"
    with open(report_file, "w") as f:
        f.write("=== Demo Multi-Agent Security Report ===\n")
        for a, v, e, r in zip(assets, vulns, exploits, risks):
            f.write(f"{a['host']} | {v['vuln']} | {e['exploit']} | {r['risk']}\n")
    return report_file
