
# Multi-Agent Security Demo

演示多 Agent 系统协作完成网络安全分析流程。

## 系统功能
- 资产解析 Agent
- 漏洞推理 Agent
- Exploit生成 Agent
- 风险评估 Agent
- 报告生成 Agent
- 可视化模块

## 运行步骤

1. 安装依赖：
```
pip install matplotlib
```

2. 运行演示：
```
python main.py
```

3. 输出：
- demo_output/report_demo.txt
- visualization/demo_plot.png
